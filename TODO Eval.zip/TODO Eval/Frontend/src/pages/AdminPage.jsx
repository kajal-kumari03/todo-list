    import React from 'react'
    
    const AdminPage = () => {
      return (
        <div>
          <p>This is home </p>
        </div>
      )
    }
    
    export default AdminPage
    